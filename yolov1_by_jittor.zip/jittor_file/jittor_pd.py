GL_CLASSES = ['closeEyes','yawn']

GL_NUMBBOX = 2
GL_NUMGRID = 7
# STATIC_DATASET_PATH = r'C:\Users\xuanq\Desktop\VOC2012'
STATIC_DATASET_PATH = r'F:\Develop\Python_File\DownLoad\YOLOv1-from-scratch\dataset'
STATIC_DEBUG = False  # 调试用